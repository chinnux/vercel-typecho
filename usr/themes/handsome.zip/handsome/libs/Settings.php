<?php

/**
 * 外观设置管理界面
 */

class Settings{

    public static function initCdnSetting()
    {
        $options = mget();
        if (!defined('THEME_URL')) {//主题目录的绝对地址
            @define("THEME_URL", rtrim(preg_replace('/^' . preg_quote($options->siteUrl, '/') . '/', $options->rootUrl . '/', $options->themeUrl, 1), '/') . '/');
        }


        if (!defined('PUBLIC_CDN')) {
            Utils::initCDN();
        }
    }


    /**
     * 检查更新逻辑
     * @return string
     */
    public static function checkupdatejs()
    {
        $current_version = Handsome::version;
        $themeUrl = THEME_URL;
        Settings::initCdnSetting();

        $options = mget();
        $blog_url = $options->rootUrl;
        $code = '"' . md5($options->time_code) . '"';
        $root = base64_decode(CDN_Config::version);

        $root_use = base64_decode(CDN_Config::debug);
        $html = <<<EOF
<script>
var blog_url="$blog_url";var code=$code;var root="$root";var root_use="$root_use";var version = "$current_version";
</script>  
EOF;

        return $html;
    }


    /**
     * 输出用户欢迎信息
     * @return string
     */
    public static function useIntro()
    {
//        $version = (string)self::version;
        $randomColor = Handsome::getBackgroundColor();
        Settings::initCdnSetting();
        $PUBLIC_CDN_ARRAY = json_decode(PUBLIC_CDN,true);
        $mduiCss =  THEME_URL ."assets/libs/mdui/mdui.min.css";
        $db = Typecho_Db::get();
        $backupInfo = "";
        if ($db->fetchRow($db->select()->from('table.options')->where('name = ?', 'theme:HandsomePro-X-Backup'))) {
            $backupInfo = '<div class="mdui-chip" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-green"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span class="mdui-chip-title">数据库存在主题数据备份</span></div>';
        } else {
            $backupInfo = '<div class="mdui-chip" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-red"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span 
        class="mdui-chip-title" style="color: rgb(255, 82, 82);">没有主题数据备份</span></div>';
        }


        //显示一些提示信息，帮助用户查看问题
        $pluginExInfo = "";
        echo '<script>
var handsome_info = {}
handsome_info.version = "'.Handsome::version.'"
</script>';

        //检测是否启用了Handsome
        if (!Handsome::getPluginCorrect()){
            echo "<script>
                   handsome_info.plugin_not_enable = true;
                    </script>";
        }else{
            //启动了插件，检测版本是否一致
            if (Handsome::getPluginVersion("Handsome_Plugin", "Handsome") !== Handsome::version){
                echo '<script>handsome_info.plugin_version_error = true</script>';
            }

        }
        
        if (Handsome::isPluginAvailable("EditorMD_Plugin", "EditorMD")) {
            if (Helper::options()->plugin('EditorMD')->isActive == "1") {
                //出现弹窗提示不要使用editomd
//                echo "<script>alert('检测到开启了EditorMD插件，请禁用该插件，新版本主题Handsome插件自带更现代化的markdown编辑器，基本包含editormd所有功能。')</script>";
                $pluginExInfo = "开启了EditorMD插件，注意在handsome 插件中编辑器选择其他。 </br>";
            }
        }
        if ($pluginExInfo == "") {
            $pluginExInfo = "暂无插件提示~使用愉快";
        }

        if (!Handsome::isPluginAvailable("Handsome_Plugin", "Handsome")) {
            $pluginInfo = '<div class="mdui-chip" mdui-tooltip="{content: 
    \'' . $pluginExInfo . '\'}" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-red"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span 
        class="mdui-chip-title" style="color: rgb(255, 82, 82);" >配套插件未启用，请及时安装</span></div>';
        } else {
            $pluginInfo = '<div class="mdui-chip" mdui-tooltip="{content: 
    \'' . $pluginExInfo . '\'}" style="color: rgb(26, 188, 156);"><span 
        class="mdui-chip-icon mdui-color-green"><i class="mdui-icon material-icons">&#xe8ba;</i></span><span class="mdui-chip-title">配套插件已启用</span></div>';
        }

        $authInfo = '<div class="mdui-chip"><span 
        class="mdui-chip-icon mdui-color-red" id="auth_icon"><i class="mdui-icon material-icons">&#xe627;</i></span><span class="mdui-chip-title" id="auth_text">授权啥？都破解了</span></div>';

//        self::initAll();

        $version = Handsome::version;
        $img = Typecho_Widget::widget('Widget_Options')->BlogPic;
        return <<<EOF
<link href="{$mduiCss}" rel="stylesheet">
<div class="mdui-card">
  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">    
    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    <div class="mdui-card-menu">
      <button class="mdui-btn mdui-btn-icon mdui-text-color-white"><i class="mdui-icon material-icons">share</i></button>
    </div>
  </div>
  
  <!-- 卡片的标题和副标题 -->

<div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div id="handsome_header" class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="$img"/>
    <div class="mdui-card-header-title">您好</div>
    <div class="mdui-card-header-subtitle">欢迎使用handsome主题，点击查看一封信个鬼鬼</div>
  </div>
  
  <!-- 卡片的标题和副标题 -->
<div class="mdui-card-primary mdui-p-t-1">
    <div class="mdui-card-primary-title">handsome {$version} Pro</div>
    <div class="mdui-card-primary-subtitle mdui-row mdui-row-gapless  mdui-p-t-1 mdui-p-l-1">
        
        <div id="update_notification" class="mdui-m-r-2">
            <div class="mdui-progress">
                <div class="mdui-progress-indeterminate"></div>
            </div>
            <div class="checking">检查更新中……</div>
        </div>
        
       
                <!--备份情况-->
                {$backupInfo}
                <!--插件情况-->
                {$pluginInfo}
                
                {$authInfo}

     </div>
  </div>  
  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple showSettings" mdui-tooltip="{content: 
    '展开所有设置后，使用ctrl+F 可以快速搜索🔍某一设置项'}">展开所有设置</button>
    <button class="mdui-btn mdui-ripple hideSettings">折叠所有设置</button>
    <button class="mdui-btn mdui-ripple recover_back_up" mdui-tooltip="{content: '从主题备份恢复数据'}">从主题备份恢复数据</button>
    <button class="mdui-btn mdui-ripple back_up" 
    mdui-tooltip="{content: '1. 仅仅是备份handsome主题的外观数据</br>2. 切换主题的时候，虽然以前的外观设置的会清空但是备份数据不会被删除。</br>3. 所以当你切换回来之后，可以恢复备份数据。</br>4. 备份数据同样是备份到数据库中。</br>5. 如果已有备份数据，再次备份会覆盖之前备份'}">
    备份主题数据</button>
    <button class="mdui-btn mdui-ripple un_back_up" mdui-tooltip="{content: '删除handsome备份数据'}">删除现有handsome备份</button>
  </div>
  
  
</div>

  
</div>

EOF;
    }



    /**
     * 输出到后台外观设置的css
     * @return string
     */
    public static function styleoutput()
    {
        $themeUrl = THEME_URL;
        $versionPrefix = Handsome::version . Handsome::$versionTag;

        $randomColor = Handsome::getBackgroundColor();
        //$randomColor[0] = "#fff";
        return <<<EOF
<style>
:root{--randomColor0:{$randomColor[0]};--randomColor1:{$randomColor[1]};}
</style>
    <link rel="stylesheet" href="{$themeUrl}assets/css/admin/editor.min.css?v={$versionPrefix}" type="text/css" />
    <link rel="stylesheet" href="{$themeUrl}assets/css/admin/admin.min.css?v={$versionPrefix}" type="text/css" />
EOF;
    }


    public static function initAll(){
        $options = mget();
        $blog_url = $options->rootUrl;
        $code = '"' . md5($options->time_code) . '"';
        $root = base64_decode(CDN_Config::version);
        $root_use = base64_decode(CDN_Config::debug);
        $version = Handsome::version;
        $html = <<<EOF
<script>
var blog_url="$blog_url";var code=$code;var root="$root";var root_use="$root_use";var version = "$version";
</script>
EOF;

        return $html;

    }


    public static function futureCustom(){

    }


}


