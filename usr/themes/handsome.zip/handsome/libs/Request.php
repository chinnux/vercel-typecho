<?php


if (!defined('__TYPECHO_ROOT_DIR__')) {
	exit;
}
require_once("interface/Ajax.php");
require_once("Utils.php");
require_once("Content.php");

function themeInit($self)
{
	@mset("show_footer", 1);
	@mset("post_content", 2);
	@mset("typecho_content", true);
	
	Database::initField();
	Utils::initGlobalDefine();
	Ajax::request();
	if($_POST != null){
		Ajax::post();
	}
}

